package org.cap.conotroller;

import java.util.List;
import java.util.Map;

import org.cap.dao.IProductDao;
import org.cap.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProductController {

	
	@Autowired
	private IProductDao productDao;
	
	
	@PostMapping(path= "/products", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Object> createProduct(@RequestBody Product product){
		
		Product productItem = productDao.findProduct(product.getProductId());

		if(productItem!=null) {
			return new ResponseEntity<Object>("Sorry! Product ID already exist",
					HttpStatus.NOT_FOUND);
		}

		
		List<Product> products=productDao.createProduct(product);
		
		if(products==null) {
			return new ResponseEntity<Object>("Sorry! No Items Available! Error adding the product",
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Object>(products, HttpStatus.OK);
	}
	
	@PutMapping(path="/products/{productId}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Object> updateProduct(@PathVariable("productId") Integer productId, @RequestBody Product updatedProduct){
		

		Product product =productDao.updateProduct(productId, updatedProduct);
		if(product == null)
			return new ResponseEntity<Object>("Sorry! invalid Prodcut ID",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Object>(product, HttpStatus.OK);
	}
	
	@PatchMapping(path="/products/{productId}",produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Object> updatePartialProduct(@PathVariable("productId") Integer productId, @RequestBody Map<String,Object> updatedProduct){
		
		
		Product product =productDao.updatePartialProduct(productId, updatedProduct);
		if(product == null)
			return new ResponseEntity<Object>("Sorry! invalid Product ID",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Object>(product, HttpStatus.OK);
	}
	
	
	
	
	
	
	
	@DeleteMapping(path= "/products/{productId}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Object> deleteProduct(
			@PathVariable("productId") Integer productId){
		List<Product> products=productDao.deleteProduct(productId);
		
		if(products==null) {
			return new ResponseEntity<Object>("Sorry! Product Id not exists! Deletion Error!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Object>(products, HttpStatus.OK);
	}
	
	
	@GetMapping(path="/products", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Object> getAllProducts(){
		List<Product> products=productDao.getAllProducts();
		Product pr = new Product();

		if(products==null || products.isEmpty() ) {
			return new ResponseEntity<Object>("Sorry! No Items Available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Object>(products, HttpStatus.OK);
	}
	
	@GetMapping(path="/products/{productId}",produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Object> findProducts(
			@PathVariable("productId") Integer productId ){
		Product product=productDao.findProduct(productId);
		
		if(product==null ) {
			return new ResponseEntity<Object>("Sorry!Product Id Not Found!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Object>(product, HttpStatus.OK);
	}
	
}

package org.cap.dao;

import java.util.List;
import java.util.Map;

import org.cap.model.Product;

public interface IProductDao {
	
	public List<Product> getAllProducts();

	public Product findProduct(Integer productId);

	public List<Product> deleteProduct(Integer productId);
	
	public List<Product> createProduct(Product product);
	public Product updateProduct(Integer productId,Product product);
	public Product updatePartialProduct(Integer productId, Map<String,Object> productData);

}

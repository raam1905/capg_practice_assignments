package org.cap.dao;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Manufacturer;
import org.cap.model.Product;
import org.springframework.stereotype.Repository;
import org.springframework.util.ReflectionUtils;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao {
	
	
	private static AtomicInteger productId=new AtomicInteger(1234);
	private static AtomicInteger manufacturerId=new AtomicInteger(1);
	private static List<Product> db=getDummyDB(); 
	
	
	private static List<Product> getDummyDB(){
		List<Product> products=new ArrayList<Product>();
			Manufacturer manufatcturer=new Manufacturer(manufacturerId.getAndIncrement(), "Tom", "Jerry", "tom@gmail.com");
			products.add(new Product(productId.getAndIncrement(), "Laptop", 34, 45000.0, manufatcturer));
			products.add(new Product(productId.getAndIncrement(), "Mobile",12, 23000.0, manufatcturer));
			
			Manufacturer manufatcturer1=new Manufacturer(manufacturerId.getAndIncrement(), "Jack", "Thomson", "jack@gmail.com");
			products.add(new Product(productId.getAndIncrement(), "HeadSet", 23, 300.0, manufatcturer1));
			products.add(new Product(productId.getAndIncrement(), "Printer", 11, 67000.0, manufatcturer1));
			
			
		
		return products;
	}
	

	@Override
	public List<Product> getAllProducts() {
		
		return db;
	}


	@Override
	public Product findProduct(Integer productId) {
		for(Product product:db) {
			if(product.getProductId()==productId)
				return product;
		}
		return null;
	}


	@Override
	public List<Product> deleteProduct(Integer productId) {
		boolean flag=false;
		Iterator<Product> iterator = db.iterator();
		while(iterator.hasNext()) {
			Product product= iterator.next();
			if(product.getProductId()==productId) {
				flag=true;
				iterator.remove();
				break;
			}
		}
		if(flag)
			return db;
		else
			return null;
	}


	@Override
	public List<Product> createProduct(Product product) {
		db.add(product);
		return db;
	}


	@Override
	public Product updateProduct(Integer productId, Product updatedProduct) {
		// TODO Auto-generated method stub
		Product prod = findProduct(updatedProduct.getProductId());
		
		if(prod != null) {
			prod.setManufatcturer(updatedProduct.getManufatcturer());
			prod.setPrice(updatedProduct.getPrice());
			prod.setProductName(updatedProduct.getProductName());
			prod.setQuantity(updatedProduct.getQuantity());
			
		}
		return prod;
	}


	@Override
	public Product updatePartialProduct(Integer productId,Map<String, Object> productData) {

		
		Product prod = findProduct(productId);
		
		if(prod != null) {
			productData.forEach((k,v)->{
				if("manufatcturer".equals(k)) {
					Manufacturer manufacturerDtls = prod.getManufatcturer();
					
					@SuppressWarnings("unchecked")
					Map<String, Object> manufacDtlData = (Map<String, Object>) productData.get("manufatcturer");
						manufacDtlData.forEach((k1,v1)->{
							Field field = ReflectionUtils.findField(Manufacturer.class, k1);
							field.setAccessible(true);
							ReflectionUtils.setField(field, manufacturerDtls, v1);

					});
				}
				else {
					Field field = ReflectionUtils.findField(Product.class, k);
					field.setAccessible(true); 
				 	ReflectionUtils.setField(field, prod, v);
				}
				 

				
			});
		}
		return prod;
	}
	
	

}

package com.springboot.h2.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Min;

@Entity
public class Account {

	@Id
	@GeneratedValue
	private String accno;
	private String acctype;
	
	@Min(value= 1000,  message = "Minimum Balance Limit Violation") 
	private int totalAmout;
	
	@ManyToOne(fetch=FetchType.LAZY)
	Customer cust;

	public Account() {
	}

	public String getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	

	public int getTotalAmout() {
		return totalAmout;
	}

	public void setTotalAmout(int totalAmout) {
		this.totalAmout = totalAmout;
	}

	public String getAcctype() {
		return acctype;
	}

	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}

}

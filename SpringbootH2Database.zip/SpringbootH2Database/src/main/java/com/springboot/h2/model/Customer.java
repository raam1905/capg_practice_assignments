package com.springboot.h2.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Customer {

	
	@Id
	@GeneratedValue
	private String custid;
	private String name;
	private int age;
	private String emailAddress;
	private String password;


	

	@OneToMany(mappedBy="cust")
	private List<Account> accountsList;
	
	public Customer() {	}


	public Customer(String custid, String name, int age, String emailAddress) {
		this.custid = custid;
		this.name = name;
		this.age = age;
		this.emailAddress = emailAddress;
	}
	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}

	public String getCustid() {
		return custid;
	}

	public void setCustid(String custid) {
		this.custid = custid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}


	public List<Account> getAccountsList() {
		return accountsList;
	}


	public void setAccountsList(List<Account> accountsList) {
		this.accountsList = accountsList;
	}



	
}

package com.springboot.h2.serv;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.h2.model.Account;
import com.springboot.h2.model.Customer;
import com.springboot.h2.repo.AccountRepository;
import com.springboot.h2.repo.CustomerRepository;

@Service
public class CustomerService {

	// @Autowired annotation provides the automatic dependency injection.
	@Autowired
	CustomerRepository repository;
	
	@Autowired
	AccountRepository accRepository;

	public void save(final Customer customer) {
		repository.save(customer);
	}
	public void saveAcct(final Account account) {
		accRepository.save(account);
	}

	public List<Customer> getAll() {
		final List<Customer> customers = new ArrayList<>();
		repository.findAll().forEach(customer -> customers.add(customer));
		return customers;
	}

	public List<Account> getAllAccounts(String custId) {

		Optional<Customer> cust = repository.findById(custId);
		if (cust.isPresent() == false)
			return null;
		return cust.get().getAccountsList();

	}
	
	@Transactional
	public int makeTransfer(String string,String srcacc,String destnAcc,Integer amtToBeTransferred) {

		Optional<Account> srcAcct = accRepository.findById(srcacc);
		
		Optional<Account> destnAcct = accRepository.findById(destnAcc);
		if (srcAcct.isPresent() == false || destnAcct.isPresent() == false  )
			return -1;
		
		destnAcct.ifPresent((a)->a.setTotalAmout(a.getTotalAmout()+ amtToBeTransferred));
		saveAcct(destnAcct.get());
		
		srcAcct.ifPresent((a)->a.setTotalAmout(a.getTotalAmout()- amtToBeTransferred));
		saveAcct(srcAcct.get());
		
		return 0;

	}
	
	public Customer validateLogin(Customer cust) {
		return repository.findByCustidAndPassword(cust.getCustid(),cust.getPassword());
	}

}

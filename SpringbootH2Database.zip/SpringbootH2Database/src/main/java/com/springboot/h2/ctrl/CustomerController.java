package com.springboot.h2.ctrl;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springboot.h2.model.Account;
import com.springboot.h2.model.Customer;
import com.springboot.h2.serv.CustomerService;

@Controller		
public class CustomerController {

	private final Logger log = LoggerFactory.getLogger(this.getClass()); 

	
	@Autowired
	CustomerService service;

	

	@GetMapping(value= "/login")
	public String loadLogin( Model model) {
		log.info("get all account");
		
		 
        model.addAttribute("custInfo", new Customer());
		return "show-login";
	}
	
	@RequestMapping(value= "/validatelogin", method=RequestMethod.POST)
	public String validateLogin(@ModelAttribute Customer custInfo, Model model, HttpSession session) {
		log.info("get all account");
		Customer cust = service.validateLogin(custInfo);
		
		
		if(cust == null) {
		
			

			return "unauthorized";
		}
		else {
			session.setAttribute("custInfo", cust);
			return "redirect:/customer/accountslist";
			/*List<Account> list = service.getAllAccounts(custInfo.getCustid());
			 
	        model.addAttribute("accts", list);
			return "list-accounts";*/
			
		}
			
	}
	
	@RequestMapping(value= "/customer/accountslist")
	public String getAcctsList(Model model, HttpSession session) {
		log.info("get all account");
	
		
		Customer cust = (Customer) session.getAttribute("custInfo");
		if(cust == null)
			return "redirect:/login";
		List<Account> list = service.getAllAccounts(cust.getCustid());
		 
        model.addAttribute("accts", list);
		return "list-accounts";
	}
	
	
	@RequestMapping(value= "/customer/selftransfer",method=RequestMethod.GET)
	public String showSelfTransfer(HttpSession session, Model model) {

		Customer cust = (Customer) session.getAttribute("custInfo");
		if(cust == null)
			return "redirect:/login";
		model.addAttribute("acctList", service.getAllAccounts(cust.getCustid()));
		return "transfer";
	}

	@RequestMapping(value= "/customer/dotransfer",method=RequestMethod.POST)
	public  String doSelfTransfer(HttpSession session, @RequestParam String srcacc, @RequestParam String destnacc, @RequestParam Integer amt) {
		

		Customer cust = (Customer) session.getAttribute("custInfo");
		if(cust == null)
			return "show-login";
		
		service.makeTransfer(cust.getCustid(),srcacc,destnacc,amt);
		return "redirect:/customer/accountslist";
		
	}

	
	
	@GetMapping(value= "/customers/{custid}/accounts/{acctno}")
	public Account getIndividualAcctDetails(@PathVariable("custid") Integer custid, @PathVariable("accno") Integer accno) {
		log.info("get individual account");
		
		return null;
	}
	
	/*
	 * @GetMapping(value= "/customers/{custid}/accounts/selftransfer")
	 * public @ResponseBody int doTransfer(@PathVariable("custid") Integer
	 * custid, @RequestParam Integer srcacc, @RequestParam Integer
	 * destnacc, @RequestParam Integer amt) { log.info("Transfer done"); return
	 * service.makeTransfer(""+custid,srcacc,destnacc,amt);
	 * 
	 * }
	 */
	
	@GetMapping(value= "/customers")
	public List<Customer> getAllcustomers() {
		
		
		return service.getAll();
	}
	
}
